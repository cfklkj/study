document.write('<script  type="text/javascript" src="js/util.js"></script>')  
document.write('<script  type="text/javascript" src="js/mem.js"></script>')  
document.write('<script  type="text/javascript" src="js/lib/base64.js"></script>')  
document.write('<script  type="text/javascript" src="js/lib/pako.min.js"></script>')  
document.write('<script  type="text/javascript" src="js/login.js"></script>')  
document.write('<script  type="text/javascript" src="js/logOut.js"></script>')  
document.write('<script  type="text/javascript" src="js/webHttp.js"></script>')  
document.write('<script  type="text/javascript" src="js/webSocket_local.js"></script>') 
document.write('<script  type="text/javascript" src="js/define.js"></script>')  
document.write('<script  type="text/javascript" src="js/chat.js"></script>')  
document.write('<script  type="text/javascript" src="js/chatLeft_search.js"></script>')  
document.write('<script  type="text/javascript" src="js/chatLeft.js"></script>') 
document.write('<script  type="text/javascript" src="js/chatRight.js"></script>')  
document.write('<script  type="text/javascript" src="js/imgDlg.js"></script>')    
window.onload = main  

function main(){
    outDiv.showLogin();
}
 