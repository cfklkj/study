var defines = defines || {};
var imDefine = defines.Method = {  
	Opt_login:110011,
	Opt_msg:110005,
	Opt_heart:110013,
	Opt_revmsg:120004,
	Act_read:2002,
	Act_write:2001,
	Act_msgLen:2004,
	Act_Login:2006,
	Act_pub:2007,
	Act_route:2008,
	Err_reLogin:140022,
	Conversation_c2c:130003,
    Err_null:200,
    act_selectContent:"selectContent",
    act_selectContentEle:"selectContentEle",
	act_selectContentLogLenth:"selectContentLog",
	search_content:"search_content",
	chat_chat:"chat", 
	chat_img:"image",
	chat_file:"file",
	mem_loginData:"loginData", 
	mem_Lchoice:"leftChoice",

	div_bodys:"bodys",
}

 